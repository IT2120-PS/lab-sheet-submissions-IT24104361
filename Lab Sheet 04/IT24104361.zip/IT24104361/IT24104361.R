#1
setwd("C:\\Users\\it24104361\\Desktop\\IT24104361")
data<-read.table("DATA 4.txt",header = TRUE,sep =" " )
fix(data)
attach(data)

#Exercise
#1
branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")
#3
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", horizontal=TRUE)
#4
summary(branch_data$Advertising_X2)
IQR_Advertising <- IQR(branch_data$Advertising_X2)
print(IQR_Advertising)
#5
get.outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

get.outliers(branch_data$Years_X3)

